<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'يجب تزويد عنوان بريد الكتروني لكي يتم الإرسال إليه.';
$_lang['mail_err_derive_getmailer'] = 'محاولة استدعاء التابع المجرد  _getMailer() في الصف modMail. يجب تنفيذ هذا التابع في صف مشتق من modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]]  هي واصفة PHPMailer غير صالحة وسيتم تجاهلها في التحقيق.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer لا يدعم العناوين المحددة الغير مضبطة, استخدم reset() لحذف جميع المستقبلين ثم اضف العناوين التي تريد الإرسال اليها.';