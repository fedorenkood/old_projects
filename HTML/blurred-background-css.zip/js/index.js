$(function() {
	$( ".box" ).draggable();
});