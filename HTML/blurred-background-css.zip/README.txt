A Pen created at CodePen.io. You can find this one at http://codepen.io/ariona/pen/geFIK.

 While waiting for the official property, the trick is to create blurred version of the background, and set the background property both of them (main body background and box that want to be blurred) to be cover sized and fixed.