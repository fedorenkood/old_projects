var opentxt = document.getElementById('Open');
var hidetxt = document.getElementById('Close');

opentxt.onclick = function opentxt(){
    param=document.getElementById("NotImporT"); 
    open=document.getElementById("Open"); 
    close=document.getElementById("Close"); 
    if(param.style.display = "none") { 
        param.style.display = "block"; 
        open.style.display = "none";
    }
    else {
            param.style.display = "none";
            open.style.display = "block";
         } 
}

hidetxt.onclick = function(){ 
    param=document.getElementById("NotImporT"); 
    param.style.display = "none"; 
    open=document.getElementById("Open"); 
    if(open.style.display = "none"){
        open.style.display = "block";
    }
} 