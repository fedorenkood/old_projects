A Pen created at CodePen.io. You can find this one at http://codepen.io/suez/pen/oXLroX.

 Based on Zee Young dribbble - https://dribbble.com/shots/2067564-Replace

No animation libraries. Not working in IE. Right now tested only in last Chrome and FF. Totally not optimized for mobile.

All SVG are hand-written :) Plane fly animation made with keyframes.