<section id="main" class="clearfix home-default">
		<div class="container">
			
			<!-- main-content -->
			<div class="main-content">
				<!-- row -->
				<div class="row">
					<!-- product-list -->
					<div class="col-md-12">
						<!-- categorys -->
						<div class="section">
							<div class="row">
								<div class="col-md-12">

							<h3><?php echo $lang['affiliate_program']; ?></h3>
							<hr/>
<?php echo $lang['any_registered_user']; ?> <?php echo $settings['name']; ?> <?php echo $lang['can_use_affiliate_program']; ?> <?php echo $lang['you_can_earn']; ?> <?php echo $settings['referral_comission']; ?>% <?php echo $lang['of_all_exchanges']; ?><br><br>
					
					<b><?php echo $lang['how_it_works']; ?></b><br/>
					<?php echo $lang['how_it_works_text_1']; ?> <?php echo $settings['referral_comission']; ?>% <?php echo $lang['how_it_works_text_2']; ?> <?php echo $settings['referral_comission']; ?>% <?php echo $lang['of']; ?> 5
					
					
					<br><br><b><?php echo $lang['how_to_use']; ?></b>
					<ol>
						<li><?php echo $lang['how_to_use_text_1']; ?></li>
						<li><?php echo $lang['how_to_use_text_2']; ?></li>
						<li><?php echo $lang['how_to_use_text_3']; ?></li>
					</ol>
				
								</div>
							</div>
						</div><!-- category-ad -->	
						
						
					</div><!-- product-list -->
				</div><!-- row -->
			</div><!-- main-content -->
		</div><!-- container -->
	</section><!-- main -->