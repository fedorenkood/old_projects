﻿<!DOCTYPE html>
<!--[if IE 8]> <html lang="ru" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="ru" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="ru"> <!--<![endif]-->  
<head>
    <title>Дома из пеноблоков под ключ. Строительство домов из газобетона. Покровский завод малоэтажного строительства | Формула дома</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Дома из пеноблоков сочетают преимущества каменного дома с высокой теплоизоляцией. Легкость в обратотке газобетона, сравнительно малый вес и высокая геометрическая точность блоков делают этот материал лучшим при желании построить именно каменный, но при этом очень теплый и недорогой дом  Покровский завод малоэтажного строительства | Формула дома">
<meta name="keywords" content="строительсво дома из пеноблоков газобетона под ключ цена">
    <meta name="author" content="">

  <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<!-- The #page-top ID is part of the scrolling feature - the data-spy and data-target are part of the built-in Bootstrap scrollspy function -->
<body id="body" data-spy="scroll" data-target=".navbar-fixed-top" class="demo-lightbox-gallery">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div>

                <a class="navbar-brand" href="index.php">
                    <span>Ф</span>ормула <span>Д</span>ома                   
                </a>
            
                <!--=== Breadcrumbs ===-->
                            <div class="breadcrumbs">
                               <!--  <div class="container"> -->
                                   <!--  <h1 class="pull-left">Blank Page</h1> -->
                                    <ul class="pull-left breadcrumb">
                                        <li><a href="/index.php">Домой</a></li>
                                        <!-- <li><a href="">Pages</a></li> -->
                                        <li class="active">Газосиликат</li>
                                    </ul>
                                <!-- </div>/container -->
                            </div><!--/breadcrumbs-->
                        <!--=== End Breadcrumbs ===-->
            </div></div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li class="page-scroll home">
                        <a href="/index.php"><i class="fa fa-home"></i></a>
                    </li>
                    
                    <li class="page-scroll">
                        <a href="#intro">Технология</a>
                    </li>
                     <li class="page-scroll">
                        <a href="#services">Строительство</a>
                    </li>
                   <li class="page-scroll">
                        <a href="#ds">Цены</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#portfolio">Построенное</a>
                    </li>
                    
                    <li class="page-scroll">
                        <a href="#contact">Контакты</a>
                    </li>                    
                    
                </ul>

                  <!-- Меню с телефонами  -->

                
<ul class="nav navbar-nav">
                    <li class="page-scroll home">
                        <a href="#"><i class="fa fa-phone"></i> +7(4922) 60-30-06</a>
                    </li>
                    <li class="page-scroll home">
                        <a href="#"><img src="assets/img/fd2015/logo-mts.png" height="15px"> +7(910) 177-2777</a>
                    </li>
                    <li class="page-scroll home">
                        <a href="#"><img src="assets/img/fd2015/meg.jpg" height="15px"> +7(930) 830-30-06</a>
                    </li>
                    
                               
                    
                </ul>

            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


<section id="intro" >
    <div class="parallax-quote parallaxBg">
            <div class="container">
                <div id="introtxt" class="parallax-quote-in">
                    <div class="col-md-8 col-sm-12">
                      <img src="assets/img/fd2015/06.png"  width="100%" alt="формула дома, каркасные дома, канадские дома, строительные работы">
                               <small>Пенобетон, газобетон, газосиликат</strong> – быстро набирающий популярность 
                               строительный материал, сочетающий преимущества каменного дома с высокой теплоизоляцией.<br>
                                - Формула Дома -</small>

                    </div>
                    <div class="col-md-4 col-sm-12">
                                 
                                    <div class="service-block service-block-u">
                                        <i class="icon-custom icon-color-light rounded-x fa fa-phone"></i>
                                        <h2 class="heading-md"> +7 (910) 177-2777</h2>
                                        <h2 class="heading-md"> +7(4922) 60-30-06</h2>
                                        <h2 class="heading-md">Звоните сейчас - мы ответим на любые вопрос о домах из газосиликатных блоков. <span class="page-scroll"> <a href="#contact">Заказать звонок</a></span></h2>                        
                                    </div>
                            
                    </div>
                 
                </div>
                
            </div>
            

        </div> 
          
</section>
<section id="services">
        <div class="container content-lggr introtxt">
            <div class="title-v1">
                <h1>Пенобетон, газобетон, газосиликат</h1>
                <p>Быстро набирающий популярность строительный материал, сочетающий преимущества каменного дома с высокой <span class="text-border text-border-blue tooltips" data-toggle="tooltip" data-original-title="Газосиликатные блоки марки Д500 имеют коэффициент теплопроводности всего 0,12 Вт/м, а блоки марки Д400 – 0.9 Вт/м при прочности на сжатие 2,5.">теплоизоляцией. </span>



                Легкость в обратотке, сравнительно малый вес и высокая геометрическая точность блоков делают этот материал лучшим при желании построить именно каменный, но при этом очень теплый и недорогой дом.</p>   

                <p>Соединение блоков специальным клеем сводит количество «мостиков холода» к минимуму и значительно повышает энергоэффективность дома. Широкая гамма совместимых отделочных материалов позволяет создавать дизайн дома полностью зависящий только от вкуса и возможностей заказчика. Ваш дом будет выглядеть именно так, как этого захотите именно Вы.</p>
                <p>По скорости возведения и теплоэффективности дома из газосиликата устапают, пожалуй, только <a href="karkas.php">каркасным</a> и <a href="canads.php">канадским</a> домам</p>

            </div>     
         
        </div>
         
    
 </section>

    
    <!-- Begin Content -->
    <section id="timeline">
        <div class="container content-lggr">
            <div class="title-v1">
                <h1>Этапы строительства дома из газосиликатных блоков</h1>
                   <div class="col-md-1"></div>
                    <div class="col-md-10 col-sm-12">
                        <ul class="timeline-v1">
                            <li>
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <img class="img-responsive" src="assets/img/fd2015/portfolio/built_homes_15.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                    </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Разметка строительной площадки.</a></h2>
                                        
                                    </div>
                                    
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record invert"></i></div>
                                <div class="timeline-panel">

                                <div class="carousel slide carousel-v1" id="myCarousel0">
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <img class="img-responsive" src="assets/img/fd2015/portfolio/built_homes_4.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                                    <div class="carousel-caption">
                                                        <p></p>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <img class="img-responsive" src="assets/img/fd2015/portfolio/built_homes_24.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                                    <div class="carousel-caption">
                                                        <p>Непрерывная заливка бетона - основа качественного фундамента</p>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="carousel-arrow">
                                                <a data-slide="prev" href="#myCarousel0" class="left carousel-control">
                                                    <i class="fa fa-angle-left"></i>
                                                </a>
                                                <a data-slide="next" href="#myCarousel0" class="right carousel-control">
                                                    <i class="fa fa-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>

                                    
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Фундамент</a></h2>
                                        <p>Устройство малозаглубленного ленточного фундамента либо свайного фундамента с ростверком (железобетонной лентой). Реже используется фундамент в виде монолитной плиты или полноразмерный подвал. Тип фундамента определяется в зависимости от типа грунта и предпочтений заказчика. </p>
                                        <a class="btn-u btn-u-sm" href="works.php#fund">Подробнее про фундамент...</a><br>

                                    </div>
                                    
                                </div>
                            </li>
                            <li>
                                <div class="timeline-badge primarya"><i class="glyphicon glyphicon-record"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <div class="carousel slide carousel-v1" id="myCarousel">
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <img class="img-responsive" src="assets/img/fd2015/construction/sil/14.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                                    <div class="carousel-caption">
                                                        <p></p>
                                                    </div>
                                                </div>
                                                
                                                
                                            </div>
                                            
                                            <div class="carousel-arrow">
                                                <a data-slide="prev" href="#myCarousel" class="left carousel-control">
                                                    <i class="fa fa-angle-left"></i>
                                                </a>
                                                <a data-slide="next" href="#myCarousel" class="right carousel-control">
                                                    <i class="fa fa-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Доставка </a></h2>
                                        <p>Доставка необходимого количества блоков и других строительных материалов с завода на строительную площадку. </p>
                                        
                                    </div>
                                    
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <img class="img-responsive" src="assets/img/fd2015/construction/sil/15.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                    </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Сборка</a></h2>
                                        <p>Сборка дома из блоков на специальном клее на готовом фундаменте с устройством мансардной кровли или холодного чердака.</p>
                                        
                                    </div>
                                    
                                </div>
                            </li>
                            <li>
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record invert"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <img class="img-responsive" src="assets/img/fd2015/construction/sil/7.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                    </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Крыша</a></h2>
                                        <p>Покрытие крыши выбранным заказчиком кровельным материалом.</p>
                                        
                                    </div>
                                    
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record invert"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        
                                           <img class="img-responsive" src="assets/img/fd2015/construction/can/19.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                             
                                    </div>
                                    <div class="timeline-body">
                                        <h2><a href="works.php">Окна и двери</a></h2>
                                        <p> Установка стальной входной двери и окон REHAU (собственное производство).</p>
                                        <a class="btn-u btn-u-sm" href="works.php#okna">Подробнее...</a><br>
                                    </div>
                                    
                            </li>
                            <li>
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record invert"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <img class="img-responsive" src="assets/img/fd2015/construction/sil/2.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                    </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Внутренний монтаж</a></h2>
                                        <p>Монтаж внутренних ненесущих перегородок.</p>
                                        
                                    </div>
                                    
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <img class="img-responsive" src="assets/img/fd2015/construction/kar/37.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                    </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Коммуникации</a></h2>
                                        <p>Разводка внутренних и наружных сетей (газо-, водо-, элетроснабжение, индивидуальная канализация, системы безопасности). Некоторые виды работ выполняются приглашенными фирмами, имеющими соответствующие лицензии.</p>
                                        
                                    </div>
                                    
                                </div>
                            </li>

                            
                            <li>
                                <div class="timeline-badge primary"><i class="glyphicon glyphicon-record invert"></i></div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <div class="carousel slide carousel-v1" id="myCarousel2">
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <img class="img-responsive" src="assets/img/fd2015/construction/sil/11.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы"/>
                                                    <div class="carousel-caption">
                                                        <p></p>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="carousel-arrow">
                                                <a data-slide="prev" href="#myCarousel2" class="left carousel-control">
                                                    <i class="fa fa-angle-left"></i>
                                                </a>
                                                <a data-slide="next" href="#myCarousel2" class="right carousel-control">
                                                    <i class="fa fa-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <div class="timeline-body text-justify">
                                        <h2><a href="works.php">Отделка</a></h2>
                                        <p>Внутренняя и наружная декоративная отделка всего дома и установка оборудования.</p>
                                        
                                    </div>
                                    
                                </div>
                            </li>

                            <li class="clearfix" style="float: none;"></li>
                        </ul>
                    </div>
            </div>     
        </div>
    </section>
            <!-- End Content -->
<div class="parallax-counter parallaxBg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                        <h4>Построили более</h4>
                            <span class="counter">12000</span> 
                            <h4>квадратных метров</h4>
                        </div>    
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                        <h4>В наших домах живет</h4>
                            <span class="counter">117</span> 
                            <h4>семей</h4>
                        </div>    
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                            <h4>Строим более</h4>
                            <span class="counter">8</span>
                            <h4>лет </h4>
                        </div>    
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                            <h4>Цена от</h4>
                            <span class="counter">8600</span>
                            <h4>рублей за кв. метр</h4>
                        </div>    
                    </div>
                </div>            
            </div>
        </div>  <section id="projekt">
    <div class="container content-lg">

        <div class="heading heading-v2 margin-bottom-20">
            <h2>Проекты</h2>

            <p>На сегодняшний день существуют тысячи готовых проектов домов на любой вкус и достаток. <br>

                Вы можете выбрать готовый проект дома в разделе нашего партнера <a href="/projectshe">«Хаус Эксперт»</a> или на одном из специализированных сайтов - каталогах проектов (ссылки на ресурсы смотрите ниже)<br>

                Мы предлагаем как адаптацию выбранного вами готового проекта так и создание нового проекта дома под ваши индивидуальные требования.<br>


                

            </p>  <a href="http://www.parthenon-house.ru/e-store/" target="_blank" title="проекты домов"><img src="http://parthenon-house.ru/images/corp/but88.gif"  alt="проекты домов" border="0" /></a>


    
    
        </div>  


    </div>  
    <div class="clients-section parallaxBg">
        <div class="container">  
            <div class="title-v1">
                <h2>Проекты можно посмотреть на этих сайтах:  </h2>
            </div>     

            <ul class="owl-clients-v2">
                <li><a href="http://www.plans.ru/"><img src="http://www.plans.ru/pics/plans.ru.gif" alt=""></a></li>
                <li class="item"><a href="http://www.postroi.ru/"><img src="http://www.postroi.ru/i/4/logo.png" alt=""></a></li>
                <!-- <li class="item"><a href="http://www.dom-plan.ru/"><img src="http://www.dom-plan.ru/templates/dom_online/images/logo-SD_1.jpg" alt=""></a></li> -->

                <li class="item"><a href="http://www.homeplans.ru/"><img src="http://www.homeplans.ru/img/tit-hp.gif" alt=""></a></li>
                <li class="item"><a href="http://www.allhomes.ru/"><img src="http://www.allhomes.ru/images/logo.jpg" alt=""></a></li>
            </ul>            
        </div>
    </div>  
</section>    
   
   <section id="ds">
        <div class="container content-lg">
            <div class="title-v1">
                <h1>Дом из газосиликата (пенобетона) - цены</h1>
                 <p>На нашем заводе Вы можете заказать различные варианты комплектации дома. Более подробную информацию можно получить по телефонам <h2 class="heading-md"> +7 (910) 177-2777</h2>
                                        <h2 class="heading-md"> +7(4922) 60-30-06</h2>
                                        <p class="heading-md">Или Вы можете 
                                        <span class="page-scroll"> <a href="#contact">заказать звонок.</a></span> </p>
                

            </div>            
    <!-- Pricing Mega v2
        <div class="row no-space-pricing pricing-mega-v2">
            <div class="col-md-4 col-sm-6 hidden-sm hidden-xs test">
                <div class="pricing hidden-area">
                    <ul  class="pricing-content list-unstyled">
                        <li><i class="fa fa-location-arrow"></i>Стройматериалы</li>
                        
                        <li><i class="fa fa-location-arrow"></i>Доставка и хранение домокомплекта</li>

                        <li> <i class="fa fa-location-arrow"></i>Сборка домокомплекта </li>
                        <li class="bg-color"> <i class="fa fa-location-arrow"></i>Коммуникации </li>
                        <li> <i class="fa fa-location-arrow"></i>Устройство Фундамента </li>
                        <li class="bg-color"> <i class="fa fa-location-arrow"></i>Внутренняя и внешняя отделка </li>
                        <li> <i class="fa fa-location-arrow"></i>Двутавр (разработка ФД) </li>
                        <li class="bg-color"> <i class="fa fa-location-arrow"></i>Гарантия на все работы и материалы </li>
                    </ul>
                     <div class="pricing-head ">
                        <h4 class="price">Стоимость за кв. м.</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-6 block">
                <div class="pricing">
                    <div class="pricing-head">
                        <h3>Базовый
                        </h3>
                    </div>
                    <ul class="pricing-content list-unstyled ">
                        <li>
                             <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Стройматериалы </span>
                        </li>
                        
                        <li class="bg-color">
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Доставка и хранение домокомплекта
                        </li>
                        

                        <li>
                            <i ></i>
                             <span class="hidden-md hidden-lg">Сборка домокомплекта
                        </li>
                        <li class="bg-color">
                            <i ></i>
                             <span class="hidden-md hidden-lg">Коммуникации 
                        </li>
                        <li>
                            <i></i>
                             <span class="hidden-md hidden-lg">Устройство Фундамента
                        </li>
                        <li>
                            <i></i>
                             <span class="hidden-md hidden-lg">Внутренняя и внешняя отделка
                        </li>
                        <li>
                            <i>1000р/кв.м.</i>
                             <span class="hidden-md hidden-lg">Двутавр (разработка ФД)
                        </li>
                        
                        
                        
                        
                        
                        <li class="bg-color"><i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg"></i>Гарантия и кредит</li>
                    </ul>
                     <div class="pricing-head">
                        <h4 class="price">
                            <i>до 10600р</i>
                            
                        </h4>
                    </div>
                    <a href="#" class="btn btn-u btn-block ">Заказать</a>
                </div>
            </div>
            <div class="col-md-2 col-sm-6 block">
                <div class="pricing">
                    <div class="pricing-head">
                        <h3>Сборка
                        </h3>
                    </div>
                    <ul class="pricing-content list-unstyled ">
                        <li>
                             <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Стройматериалы </span>
                        </li>
                        
                        <li class="bg-color">
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Доставка и хранение домокомплекта
                        </li>
                        

                        <li>
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Сборка домокомплекта
                        </li>
                        <li class="bg-color">
                            <i></i>
                             <span class="hidden-md hidden-lg">Коммуникации 
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Устройство Фундамента
                        </li>
                        <li>
                            <i ></i>
                             <span class="hidden-md hidden-lg">Внутренняя и внешняя отделка
                        </li>
                        <li>
                            <i>1000р/кв.м.</i>
                             <span class="hidden-md hidden-lg">Двутавр (разработка ФД)
                        </li>
                        
                        
                        
                        
                        
                        <li class="bg-color"><i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg"></i>Гарантия и кредит</li>
                    </ul>
                     <div class="pricing-head">
                        <h4 class="price">
                            <i>от 12000р</i>
                            
                        </h4>
                    </div>
                    <a href="#" class="btn btn-u btn-block ">Заказать</a>
                </div>
            </div>

            <div class="col-md-2 col-sm-6 block">
                <div class="pricing">
                    <div class="pricing-head">
                        <h3>"Под ключ"
                        </h3>
                    </div>
                    <ul class="pricing-content list-unstyled ">
                        <li>
                             <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Стройматериалы и крепеж</span>
                        </li>
                        
                        <li class="bg-color">
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Доставка и хранение домокомплекта
                        </li>
                        

                        <li>
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Сборка домокомплекта
                        </li>
                        <li class="bg-color">
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Коммуникации 
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Устройство Фундамента
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg">Внутренняя и внешняя отделка
                        </li>
                        <li>
                            <i>1000р/кв.м.</i>
                             <span class="hidden-md hidden-lg">Двутавр (разработка ФД)
                        </li>
                        
                        
                        <li class="bg-color"><i class="fa fa-check"></i>
                             <span class="hidden-md hidden-lg"></i>Гарантия и кредит</li>
                    </ul>
                     <div class="pricing-head">
                        <h4 class="price">
                            <i>от 24000р</i>
                            
                        </h4>
                    </div>
                    <a href="#" class="btn btn-u btn-block ">Заказать</a>
                </div>
            </div>

            </div>
        </div>
         End Pricing Mega v2 -->
            
        </div>
        
   </section>

   

       <div  class="parallax-counter parallaxBg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-xs-12">
                       <h4> Также к услугам наших клиентов собственный магазин отделочных материалов и рынок строительных материалов по адресу:  <strong><a class="grtxt" href="#mymap" >г. Петушки, ул. Профсоюзная д.41</a> </strong>   </h4>
                    </div>
                    <div class="col-sm-4 col-xs-12">
                       <h4> Телефон для справок <br><strong>+7(49243)2-71-30 </strong> <br>  Нелли Алексеевна</h4> 
                    </div>
                    
                </div>            
            </div>
        </div>      <!-- Portfolio Section -->
    <section id="portfolio" class="about-section">
        <div class="container content-lg">
            <div class="heading heading-v2 margin-bottom-20">
                <h2>ПОСТРОЕННЫЕ ДОМА</h2>
                <p>За все время нашей работы мы построили более <strong>12000 кв.м.</strong> 
                    При <strong>строительстве и отделке</strong> используем проверенные материалы, точные инструменты и так мы уверенны в качестве нашей работы. </p>
<p>Мы считаем, что лучшей рекомендацией являются довольные клиенты, и именно поэтому мы всегда рады будем показать наше производство, дома, 
построенные нами, так же Вы можете пообщаться с их владельцами.</p>
                           
            </div>


            <div class="cube-portfolio">
                <div id="filters-container" class="cbp-l-filters-button">
                    <div data-filter="*" class="cbp-filter-item-active cbp-filter-item"> Все </div>
                    <div data-filter=".canada" class="cbp-filter-item"> Канадские дома</div>
                    <div data-filter=".karkas" class="cbp-filter-item"> Каркасные дома </div>
                    <div data-filter=".silikat" class="cbp-filter-item"> Газосиликат </div>
                    <div data-filter=".otdel" class="cbp-filter-item"> Отделка </div>
                    <div data-filter=".works" class="cbp-filter-item"> Отдельные работы </div>
                </div><!--/end Filters Container-->

                <div id="grid-container" class="cbp-l-grid-gallery">
                    <div class="cbp-item silikat otdel">
                        <a href="assets/ajax/project1.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0006.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Газосиликат (мкр.Юрьевец)</div>
                                        <div class="cbp-l-caption-desc">Строительство и отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel">
                        <a href="assets/ajax/project2.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0013.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Каркасный дом (п.Ючмер, Владимирская обл.)</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel">
                        <a href="assets/ajax/project3.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0015.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия каркасных домов "Гросс"</div>
                                        <div class="cbp-l-caption-desc">Строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel works">
                        <a href="assets/ajax/project4.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0029.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия каркасных домов "ЭКО"</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item canada karkas works">
                        <a href="assets/ajax/project5.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0037.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия домов "Крутово"</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item canada karkas  works">
                        <a href="assets/ajax/project6.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0041.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Малые архитектурные формы</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel">
                        <a href="assets/ajax/project7.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0051.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия каркасных домов "БОЛДИНО"</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="karkas cbp-item otdel">
                        <a href="assets/ajax/project10.html" class="cbp-caption cbp-singlePageInline" data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/of2.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Классический американский дом</div>
                                        <div class="cbp-l-caption-desc">Любые пожелания клиента </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                                
                </div>

                <div class="cbp-l-loadMore-button">
                    <a href="assets/ajax/loadMore.html" class="cbp-l-loadMore-button-link">Загрузить больше</a>
                </div>
            </div>
        </div>

        

                      
    </section>
    <!--  </section>-->
    <!-- Contact Section -->
    <section id="contact" class="contacts-section">
        <div class="container content-lg">
            <div class="title-v1">
                <h2>Контакты</h2>
                <p>Мы всегда можем встретиться в одном из наших офисов <br> или позвоните и наш сотрудник встретится в любом удобном Вам месте.
                <i class="fa fa-phone"></i>+7(910)177-2777, +7(4922) 60-30-06. 
                    

                </p>
                
            </div>
<!-- <div id="alert" class="alert alert-success fade in margin-bottom-40 hidd">
                     <h4>Доставлено!</h4>
                     Мы свяжемся с Вами в ближайшее время.
                 </div>  --> 
            <div class="row contacts-in">
                <div class="col-md-6 md-margin-bottom-40">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-home"></i> г. Владимир, Дворянская 27а </li>
                        <li><i class="fa fa-phone"></i> <tel>+7(4922) 60-30-06</tel></li>

                        <li><i class="fa fa-home"></i> г. Петушки, ТЦ Пятерочка </li>
                        <li><i class="fa fa-phone"></i> <tel>+7(49243) 2-71-10</tel></li>
                        <!-- <li><i class="fa fa-home"></i> г. Покров, ул.Ленина, 92 </li>
                        <li><i class="fa fa-phone"></i> <tel>+7(49243)  6-75-92</tel></li> -->
                        <li><i class="fa fa-envelope"></i> <a href="mailto:house@formula-doma.ru">house@formula-doma.ru</a></li>
                        <li><i class="fa fa-globe"></i> <a href="http://formula-doma.ru">www.formula-doma.ru</a></li>
                    </ul>
                </div>

                <div class="col-md-6">
                <p>Вы так же можете заказать звонок:</p>
                   
                
                    

                    <form name='fdForm' id='fdForm'  action="" method="">
                        <label>Имя</label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-7 col-md-offset-0">
                                <input id="name" name="name" type="text" class="form-control">
                            </div>                
                        </div>
                        <label>Телефон </label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-7 col-md-offset-0">
                                <input id="phone" name="phone" type="text" class="form-control">
                            </div>                
                        </div>
                        <label>Email </label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-7 col-md-offset-0">
                                <input id="email" name="email" type="text" class="form-control">
                            </div>                
                        </div>
                        
                        <label>Сообщение</label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-11 col-md-offset-0">
                                <textarea id="txt" name="txt" rows="4" class="form-control"></textarea>
                            </div>                
                        </div>
                        
                        <p><button type="submit" name="sndbtn" class="btn-u btn-brd btn-brd-hover btn-u-dark">Отправить</button></p>
                    </form> 



                </div>
            </div> 
            
        </div>
      </section>      

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-22905167-4', 'auto');
  ga('send', 'pageview');

</script>



       <div id="mymap" class="rowmap">
            <script type="text/javascript" async  charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=ZSJtiGrWJ8ltnq8gTnIXk1iph1wYJ6T4&width=100%&height=350"></script>
       </div>

        <div class="copyright-section">
         
        

            <p>2015 &copy;  <a target="_blank" href="">ООО "Промедиа 33" - разработка и продвижение сайтов +7 (4922) 604-500</a></p>
            <a href="http://www.stroyserver.ru"><img src="http://www.stroyserver.ru/banner3.gif" width=88 height=31 border=0 alt="Строительная доска объявлений"></a><a target="_blank" href="http://www.electric-house.ru/" title="электропроводка, электрика, электромонтажные работы, электромонтаж в москве"><img src="http://www.electric-house.ru/88x31.gif" width="88" height="31" border="0" alt="электромонтажные работы, электромонтаж в москве"></a>
            <p><a href="http://www.stroi-baza.ru/job/index.php">Строительные вакансии на строительном портале </a></p>
            <!-- <ul class="social-icons">
                <li><a href="#" data-original-title="Facebook" class="social_facebook rounded-x"></a></li>
                <li><a href="#" data-original-title="Twitter" class="social_twitter rounded-x"></a></li>
                <li><a href="#" data-original-title="Goole Plus" class="social_googleplus rounded-x"></a></li>
                <li><a href="#" data-original-title="Pinterest" class="social_pintrest rounded-x"></a></li>
                <li><a href="#" data-original-title="Linkedin" class="social_linkedin rounded-x"></a></li>
            </ul> -->
            <span class="page-scroll"><a href="#intro"><i class="fa fa-angle-double-up back-to-top"></i></a></span>
        </div>


      <!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.ru/stat/?id=31076991&amp;from=informer"
target="_blank" rel="nofollow"><img src="https://bs.yandex.ru/informer/31076991/1_0_20EC20FF_00CC00FF_1_uniques"
style="width:80px; height:15px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (уникальные посетители)" onclick="try{Ya.Metrika.informer({i:this,id:31076991,lang:'ru'});return false}catch(e){}" /></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter31076991 = new Ya.Metrika({
                    id:31076991,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true,
                    trackHash:true,
                    ut:"noindex"
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/31076991?ut=noindex" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
    <!-- End Contact Section -->
    <script type="application/ld+json">
{ "@context" : "http://schema.org",
  "@type" : "Organization",
  "url" : "http://www.formula-doma.ru",
  "contactPoint" : [
    { "@type" : "ContactPoint",
      "telephone" : "+7 (4922) 60-30-06",
      "contactType" : "customer support"
    } ],
    "logo" : "http://www.formula-doma.ru/st.png" }
</script>
        
        


<!--[if lte IE 7]><style type="text/css">.jivo-btn, .jivo-btn-icon  {   display: inline;}</style><![endif]--><!-- JS Global Compulsory -->
    <!-- CSS Global Compulsory -->


    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="assets/css/line-icons.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">    
    <link rel="stylesheet" href="assets/css/pace-flash.css">
   <!--  <link rel="stylesheet" href="assets/plugins/YTPlayer/css/YTPlayer.css"> -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">    
    <link rel="stylesheet" href="assets/css/shortcode_timeline1.css">    
    <link rel="stylesheet" href="assets/css/shortcode_timeline2.css">    
    <link rel="stylesheet" href="assets/css/settings.css" type="text/css" media="screen">

    <!-- load css for cubeportfolio -->
    <link rel="stylesheet" href="assets/css/cubeportfolio.css" type="text/css" >
    <link rel="stylesheet" href="assets/css/custom-cubeportfolio.css"> 

    <!-- load main css for this page -->
    <link rel="stylesheet" href="assets/css/main.css" type="text/css" >
     <!-- CSS Theme -->    
    <link rel="stylesheet" href="assets/css/one.dark.css">

    <!-- CSS Customization -->
    <link rel="stylesheet" href="assets/css/custom.css">
   <!-- JS Global Compulsory -->
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-migrate.min.js"></script>    
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <!-- JS Implementing Plugins -->
    <script type="text/javascript" src="assets/js/smoothScroll.js"></script>    
    <script type="text/javascript" src="assets/js/jquery.easing.min.js"></script>
    <script type="text/javascript" src="assets/js/pace.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.parallax.js"></script>
    <script type="text/javascript" src="assets/js/waypoints.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.counterup.min.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.js"></script>
    <script type="text/javascript" src="assets/js/jquery.form.min.js"></script>    
    <script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.cubeportfolio.min.js"></script>
    <!-- JS Page Level-->
    <script type="text/javascript" src="assets/js/one.app.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>
    <script type="text/javascript" src="assets/js/contact.js"></script>
    <script type="text/javascript" src="assets/js/pace-loader.js"></script>
    <script type="text/javascript" src="assets/js/owl-carousel.js"></script>
    <script type="text/javascript" src="assets/js/revolution-slider.js"></script>
    <script type="text/javascript" src="assets/js/cube-portfolio-lightbox.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function() {
            App.init();
            App.initCounter();
            App.initParallaxBg();
            LoginForm.initLoginForm();
            ContactForm.initContactForm();
            OwlCarousel.initOwlCarousel();
            RevolutionSlider.initRSfullScreen();

            $('#fdForm').submit(function(e){ 
                    e.preventDefault();
                    $.ajax({
                      url: "sendForm.php",
                      type: "POST",
                      data: $('#fdForm').serialize(),
                      success: function(response) {
                        //обработка успешной отправки
                        alert("Отправлено"+this.data);
                        $('#fdForm').trigger( 'reset' );


                      },
                      error: function(response) {
                        //обработка ошибок при отправке
                        alert("Не отправлено")
                      }
                    });
                });
        });
    </script>
     <!--[if lt IE 9]>
        <script src="assets/plugins/respond.js"></script>
        <script src="assets/plugins/html5shiv.js"></script>
    <![endif]-->    <!-- BEGIN JIVOSITE CODE {literal}
<script type='text/javascript'>
(function(){ var widget_id = 'PmQI7Xdv4r';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/geo-widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
{/literal} END JIVOSITE CODE -->


<!-- START ME-TALK -->
<script type='text/javascript'>
	(function() {
		var s = document.createElement('script');
		s.type ='text/javascript';
		s.id = 'supportScript';
		s.charset = 'utf-8';
		s.async = true;
		s.src = '//me-talk.ru/support/support.js?h=a8b6f6602fa6977f8309912546a1cdcf';
		var sc = document.getElementsByTagName('script')[0];
		
		var callback = function(){
			/*
				Здесь вы можете вызывать API. Например, чтобы изменить отступ по высоте:
				supportAPI.setSupportTop(200);
			*/
		};
		
		s.onreadystatechange = s.onload = function(){
			var state = s.readyState;
			if (!callback.done && (!state || /loaded|complete/.test(state))) {
				callback.done = true;
				callback();
			}
		};
		
		if (sc) sc.parentNode.insertBefore(s, sc);
		else document.documentElement.firstChild.appendChild(s);
	})();
</script>
<!-- END ME-TALK -->

<script async="async" src="https://w.uptolike.com/widgets/v1/zp.js?pid=1396066" type="text/javascript"></script>
<!-- 33Live.Ru - Рейтинг сайтов Владимирской области --><script type="text/javascript" src="http://33live.ru/rating/counter/3399"></script><noscript><a href="http://33live.ru/?fromsite=3399" target="_blank"><img src="http://33live.ru/i/button.png" border="0" alt="Рейтинг Владимирских Сайтов" width="90" height="31"></a></noscript><!-- 33Live.Ru - Рейтинг сайтов Владимирской области -->

					<!-- Топ строительных сайтов , HTML code for http://formula-doma.ru -->
		       			<script type="text/javascript">
				          	var refer='refer=' + escape(document.referrer) + '&page=' + escape(window.location.href) + '&razresh=' + screen.width + 'x' + screen.height + '&cvet=' + screen.colorDepth + '&rand=' + Math.random(); 
							document.write('<a href="http://top.zelenopol.net/?fromsite=867"> <img src="http://top.zelenopol.net/img.php?id=867&' + refer + '"  alt="Топ строительных сайтов" width="31" height="31"> <\/a>');
			  			</script>
          				<noscript><div><a href="http://top.zelenopol.net/?fromsite=867" onclick="this.target='_blank'"><img src="http://top.zelenopol.net/img.php?id=867" alt="Топ строительных сайтов" width="31" height="31"></a></div></noscript>
					<!-- /Топ строительных сайтов , HTML code for http://formula-doma.ru -->
			    
</body>
</html>