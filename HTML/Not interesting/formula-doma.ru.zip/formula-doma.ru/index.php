﻿<!DOCTYPE html>
<!--[if IE 8]> <html lang="ru" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="ru" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="ru"> <!--<![endif]-->  
<head>
    <title>Строительство домов под ключ от Покровского завода малоэтажного домостроения | Формула дома | как построить дом недорого</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Строительство, производство, отделка домов под ключ во Владимирской Иосковской Нижегородской областях  по идивидуальному проекту - конструкция заводского изготовления соблюдается точность условие хранения материалов качество покровский завод малоэтажного строительства формула дома">
    <meta name="keywords" content="строительство домов под ключ цены купить недорого">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>

<!-- The #page-top ID is part of the scrolling feature - the data-spy and data-target are part of the built-in Bootstrap scrollspy function -->
<body id="body" data-spy="scroll" data-target=".navbar-fixed-top" class="demo-lightbox-gallery">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div>
                        <div class="row">
                            <a class="navbar-brand" href="#intro">
                                    <span>Ф</span>ормула <span>Д</span>ома                   
                            </a>
                                <!--=== Breadcrumbs ===-->
                            <div class="breadcrumbs">
                               <!--  <div class="container"> -->
                                   <!--  <h1 class="pull-left">Blank Page</h1> -->
                                    <ul class="pull-left breadcrumb">
                                        <!-- <li><a href="index.php">Покровский завод малоэтажного</a></li>
                                        <li><a href="">Pages</a></li> -->
                                        <li class="active">Покровский завод малоэтажного домостроения</li>
                                    </ul>
                                <!-- </div>/container -->
                            </div><!--/breadcrumbs-->
                        <!--=== End Breadcrumbs ===-->
                        </div>

                        
                        
                        
                </div>
                
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li class="page-scroll home">
                        <a href="#body"><i class="fa fa-home"></i></a>
                    </li>
                    
                    <li class="page-scroll">
                        <a href="#services">Технологии</a>
                    </li>
                     <li class="page-scroll">
                        <a href="#projekt">Проекты</a>
                    </li>
                   <li class="page-scroll">
                        <a href="#ds">Услуги</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#portfolio">Построенное</a>
                    </li>
                    
                    <li class="page-scroll">
                        <a href="#contact">Контакты</a>
                    </li>                    
                    
                </ul>

                <!-- Меню с телефонами  -->

                
<ul class="nav navbar-nav">
                    <li class="page-scroll home">
                        <a href="#"><i class="fa fa-phone"></i> +7(4922) 60-30-06</a>
                    </li>
                    <li class="page-scroll home">
                        <a href="#"><img src="assets/img/fd2015/logo-mts.png" height="15px"> +7(910) 177-2777</a>
                    </li>
                    <li class="page-scroll home">
                        <a href="#"><img src="assets/img/fd2015/meg.jpg" height="15px"> +7(930) 830-30-06</a>
                    </li>
                    
                               
                    
                </ul>

            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


<section id="intro" >
    <div class="parallax-quote parallaxBg">
            <div class="container">
                <div id="introtxt" class="parallax-quote-in">
                    <div class="col-md-6 col-sm-12">
                      <div class="homehouse">
                           <img src="assets/img/fd2015/04.png"  width="100%" alt="Красивый дом">
                      </div>
                      <div class="stik">  
                           <img  src="assets/img/fd2015/stik.png" width="120em" alt="Кредит на дом">
                      </div>         
                                
                    </div>
                    <div class="col-md-6 col-sm-12 alleft hedmen page-scroll">
                                 
                             <h2><a class="hedmen" href="karkas.php"><i class="fa fa-location-arrow"></i>Каркасные дома </a></h2>
                             <h2><a class="hedmen" href="canads.php"><i class="fa fa-location-arrow"></i>Канадские дома</a></h2>
                             <h2><a class="hedmen" href="silikat.php"><i class="fa fa-location-arrow"></i>Газосиликат (пенобетон)</a></h2>
                             <h2><a class="hedmen" href="works.php"><i class="fa fa-location-arrow"></i>Строительные услуги</a></h2>
                             <h2><a class="hedmen" href="smart_house"><i class="fa fa-location-arrow"></i>"Умный (Интеллектуальный) дом"</a></h2>
                             <h2><a class="hedmen " href="#shop"><i class="fa fa-location-arrow"></i>Магазин стройматериалов</a></h2>
                            
                                 <!-- Link List -->
                
                                          
                    </div>
                    <!-- <div class="col-sm-12">
                      
                           <h1 class="navbar-brand grzag" ><span>С</span>троительство домов под ключ и другие строительные работы.</h1>
                                     
                      
                    </div> -->
                 
                </div>
                
            </div>
            

        </div> 
          
</section>
<section id="services">
        <div class="container content-lggr">
            <div class="title-v1">
                <h1>Технологии строительства</h1>
                <p><strong>Формула Дома</strong> - Покровский завод малоэтажного домостроения <strong>проектирует, производит, строит и отделывает дома</strong> по нескольким, наиболее популярным, технологиям: <a href="karkas.php">Каркасные дома</a>, <a href="canads.php">Канадские дома</a>, <a href="silikat.php">Газосиликат (газобетон)</a>. Мы работаем во Владимирской, Московской и Нижегородской областях. </p>
                <p>Обращаясь к нам, Вы получаете <strong>конструкцию заводского изготовления</strong>, при котором соблюдается точность, условия хранения материалов и недоступное при кустарном изготовлении и строительстве качество. Собственное производство и строительная база позволит построить дом недорого.</p>
                <p>Мы не только <a href="works.php">строим</a>, но и являемся производителями, что позволяет получить доступные цены и гарантию качества на всех этапах производства и строительства домов.</p>
                <p>Цена готового дома, сильно зависит от проекта, типа почвы и рельефа участка, вида утеплителя и много другого, но базовые цены Вы имеете право знать: домокомплект Вы можете получить от <strong>8600р./м<sup>2</sup></strong>, а дом "под ключ" от <strong>23970р./м<sup>2</sup>.</strong></p>   
                <p>В любом случае, строительство домов - вопрос не простой и лучше договориться по телефонам о БЕСПЛАТНОЙ консультации или  <span class="page-scroll"> <a href="#contact">оставить свои контакты</a></span> - и мы совместно решим - как построить дом, который подходит именно Вам.</p>             
            </div>     
         
        </div>
         <ul class="list-unstyled row portfolio-box-v1">
            <li class="col-sm-4">
                <img class="img-responsive" src="assets/img/fd2015/karkas_00.jpg" alt="">
                <div class="portfolio-box-v1-in">
                    <h3>Каркасные дома</h3>
                    <p>Каркасный дом может быть на каркасе из дерева или металла</p>
                    <a class="btn-u btn-u-sm btn-brd btn-brd-hover btn-u-light" href="karkas.php">Подробнее...</a>
                </div>
            </li>
            <li class="col-sm-4">
                <img class="img-responsive" src="assets/img/fd2015/kanad_00.jpg" alt="">
                <div class="portfolio-box-v1-in">
                    <h3>Канадские дома</h3>
                    <p>Быстровозводимые, дома высокой энергоэффективности</p>
                    <a class="btn-u btn-u-sm btn-brd btn-brd-hover btn-u-light" href="canads.php">Подробнее...</a>
                </div>
            </li>
            <li class="col-sm-4">
                <img class="img-responsive" src="assets/img/fd2015/peno_00.jpg" alt="">
                <div class="portfolio-box-v1-in">
                    <h3>Газосиликат</h3>
                    <p>Солидность и основательность – признак дома из пенобетона</p>
                    <a class="btn-u btn-u-sm btn-brd btn-brd-hover btn-u-light" href="silikat.php">Подробнее...</a>
                </div>
            </li>


        </ul>
    
 </section>

 

        <div class="parallax-counter parallaxBg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                        <h4>Построили более</h4>
                            <span class="counter">12000</span> 
                            <h4>квадратных метров</h4>
                        </div>    
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                        <h4>В наших домах живет</h4>
                            <span class="counter">117</span> 
                            <h4>семей</h4>
                        </div>    
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                            <h4>Строим более</h4>
                            <span class="counter">8</span>
                            <h4>лет </h4>
                        </div>    
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counters">
                            <h4>Цена от</h4>
                            <span class="counter">8600</span>
                            <h4>рублей за кв. метр</h4>
                        </div>    
                    </div>
                </div>            
            </div>
        </div>  <section id="projekt">
    <div class="container content-lg">

        <div class="heading heading-v2 margin-bottom-20">
            <h2>Проекты</h2>

            <p>На сегодняшний день существуют тысячи готовых проектов домов на любой вкус и достаток. <br>

                Вы можете выбрать готовый проект дома в разделе нашего партнера <a href="/projectshe">«Хаус Эксперт»</a> или на одном из специализированных сайтов - каталогах проектов (ссылки на ресурсы смотрите ниже)<br>

                Мы предлагаем как адаптацию выбранного вами готового проекта так и создание нового проекта дома под ваши индивидуальные требования.<br>


                

            </p>  <a href="http://www.parthenon-house.ru/e-store/" target="_blank" title="проекты домов"><img src="http://parthenon-house.ru/images/corp/but88.gif"  alt="проекты домов" border="0" /></a>


    
    
        </div>  


    </div>  
    <div class="clients-section parallaxBg">
        <div class="container">  
            <div class="title-v1">
                <h2>Проекты можно посмотреть на этих сайтах:  </h2>
            </div>     

            <ul class="owl-clients-v2">
                <li><a href="http://www.plans.ru/"><img src="http://www.plans.ru/pics/plans.ru.gif" alt=""></a></li>
                <li class="item"><a href="http://www.postroi.ru/"><img src="http://www.postroi.ru/i/4/logo.png" alt=""></a></li>
                <!-- <li class="item"><a href="http://www.dom-plan.ru/"><img src="http://www.dom-plan.ru/templates/dom_online/images/logo-SD_1.jpg" alt=""></a></li> -->

                <li class="item"><a href="http://www.homeplans.ru/"><img src="http://www.homeplans.ru/img/tit-hp.gif" alt=""></a></li>
                <li class="item"><a href="http://www.allhomes.ru/"><img src="http://www.allhomes.ru/images/logo.jpg" alt=""></a></li>
            </ul>            
        </div>
    </div>  
</section>    

   <section id="ds">
        <div class="container content-lg">
            <div class="heading heading-v2 margin-bottom-20">
                <h2>Строительные услуги</h2>
                
                <p>Покровский завод малоэтажного домостроения <strong>Формула Дома</strong> оказывает <strong>отдельные</strong> услуги по строительству домов, отделке, утеплению и другим работам, которые сделают ваш дом красивым, удобным и уникальным. Вы можете ознакомиться подробнее с каждой услугой на <a href="works.php">сайте</a> или по телефонам.</p>                
            </div>            
    
            <div class="row service-box-v1">
                <div class="col-md-4 col-sm-6">
                    <div class="servive-block servive-block-default">
                        <h2 class="heading-md"><i class="icon-custom  icon-bg-u rounded-x glyphicon glyphicon-inbox"></i>
                        <a class="hover-effect" href="works.php#fund">Фундаменты</a></h2>
                        <p><strong>Фундамент</strong> - основа здания, от которой зависит долговечность дома. Наши бригады по устройству фундаментов имею богатый опыт устройства фундаментов любых типов на любых грунтах. Мы <strong>рассчитаем, спланируем и построим</strong> надежную основу строения. <a class="btn-more hover-effect" href="works.php#fund">Подробнее +</a></p>  

                        <ul class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>
                             

                                             
                    </div>

                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="servive-block servive-block-default">
                        <h2 class="heading-sm"><i class="icon-custom  icon-bg-u rounded-x glyphicon glyphicon-th"></i>
                        <a class="hover-effect" href="works.php#klad">Кладка стен</a></h2>
                        <p>Кладка стен из <strong>блоков или кирпича</strong> - ответственный процесс со множеством особенностей и способов работ. Наши специалисты возведут надежные, прочные стены с гарантией на долгие годы с учетом всех требований Вашего строения.
                        <a class="btn-more hover-effect" href="works.php#klad">Подробнее +</a></p>

                        <ul class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>

                    
                                        
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="servive-block servive-block-default">            
                        <h2 class="heading-sm"><i class="icon-custom icon-bg-u rounded-x glyphicon glyphicon-chevron-up"></i>
                        <a class="hover-effect" href="works.php#krov">Перекрытия &amp; Кровля</a></h2>
                        <p>Устройство перекрытий и кровли - работа со множеством тонкостей и деталей. С нами Вы получите уверенность в надежности крыши и внутреннего каркаса. Мы внедрили уникальную технологию легких, но прочных конструкций, что позволяет построить дом недорого.
                        <a class="btn-more hover-effect" href="works.php#krov">Подробнее +</a></p>

                        <ul class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>


                                       
                    </div>
                </div>
                  <div class="col-md-4 col-sm-6">
                    <div class="servive-block servive-block-default">
                        <h2 class="heading-md"><i class="icon-custom  icon-bg-u rounded-x glyphicon glyphicon-th-large"></i>
                        <a class="hover-effect" href="works.php#okna">Окна &amp; Зимние сады</a></h2>
                        <p>Наше предприятие является официальным дилером известных производителей оконных конструкций разных типов. Мы подберем материалы, замерим, спланируем и смонтируем оконные конструкции всех видов и сложности по разработанному или существующему проекту.
                        <a class="btn-more hover-effect" href="works.php#okna">Подробнее +</a></p>

                        <ul class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="servive-block servive-block-default">
                        <h2 class="heading-sm"><i class="icon-custom  icon-bg-u rounded-x glyphicon glyphicon-cloud"></i>
                        <a class="hover-effect" href="works.php#utepl">Утепление эковатой</a></h2>
                        <p>Мы осуществляем работы по утеплению любых строений эковатой. Современный экологичный материал, который позволяет сделать любое строение энергоэффективным. Мы можем утеплить как строящее здание, так и ранее построенное.
                        <a class="btn-more hover-effect" href="works.php#utepl">Подробнее +</a></p>

                        <ul class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>   
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="servive-block servive-block-default">            
                        <h2 class="heading-sm"><i class="icon-custom  icon-bg-u rounded-x glyphicon glyphicon-indent-left"></i>
                        <a class="hover-effect" href="works.php#otdel">Отделка Наружная &amp; Внутренняя</a></h2>
                        <p>Отделка дома выполняет множество функций. Мы умеем сделать так что бы Ваш дом был не только надежно защищен, но и выглядел красиво и отличался от других. У нас Вы найдете широкий выбор отделочных материалов, креативных дизайнеров и опытную бригаду.
                        <a class="btn-more hover-effect" href="works.php#otdel">Подробнее +</a></p>

                        <ul class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="servive-block servive-block-default">            
                        <h2 class="heading-sm"><i class="icon-custom  icon-bg-u rounded-x glyphicon glyphicon-flash"></i>
                        <a class="hover-effect" href="works.php#komm">Коммуникации</a></h2>
                        <p>Наши инженеры-специалисты <strong>рассчитают, спланируют и смонтируют</strong> под ключ все виды коммуникаций в Вашем доме - электрический сети, систему отопления, водоснабжение и водоотведение, вентиляцию. 
                        <a class="btn-more hover-effect" href="works.php#komm">Подробнее +</a></p>

                        <ul id="shop" class="list-unstyled who margin-bottom-30">
                            <li><i class="fa fa-phone"></i>+7(910)177-2777</li>
                            <li><i class="fa fa-phone"></i>+7(4922)603006</li>
                        </ul>               
                    </div>
                </div>

                

            </div>
        </div>

        </section>

        <div  class="parallax-counter parallaxBg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-xs-12">
                       <h4> Также к услугам наших клиентов собственный магазин отделочных материалов и рынок строительных материалов по адресу:  <strong><a class="grtxt" href="#mymap" >г. Петушки, ул. Профсоюзная д.41</a> </strong>   </h4>
                    </div>
                    <div class="col-sm-4 col-xs-12">
                       <h4> Телефон для справок <br><strong>+7(49243)2-71-30 </strong> <br>  Нелли Алексеевна</h4> 
                    </div>
                    
                </div>            
            </div>
        </div>      <!-- Portfolio Section -->
    <section id="portfolio" class="about-section">
        <div class="container content-lg">
            <div class="heading heading-v2 margin-bottom-20">
                <h2>ПОСТРОЕННЫЕ ДОМА</h2>
                <p>За все время нашей работы мы построили более <strong>12000 кв.м.</strong> 
                    При <strong>строительстве и отделке</strong> используем проверенные материалы, точные инструменты и так мы уверенны в качестве нашей работы. </p>
<p>Мы считаем, что лучшей рекомендацией являются довольные клиенты, и именно поэтому мы всегда рады будем показать наше производство, дома, 
построенные нами, так же Вы можете пообщаться с их владельцами.</p>
                           
            </div>


            <div class="cube-portfolio">
                <div id="filters-container" class="cbp-l-filters-button">
                    <div data-filter="*" class="cbp-filter-item-active cbp-filter-item"> Все </div>
                    <div data-filter=".canada" class="cbp-filter-item"> Канадские дома</div>
                    <div data-filter=".karkas" class="cbp-filter-item"> Каркасные дома </div>
                    <div data-filter=".silikat" class="cbp-filter-item"> Газосиликат </div>
                    <div data-filter=".otdel" class="cbp-filter-item"> Отделка </div>
                    <div data-filter=".works" class="cbp-filter-item"> Отдельные работы </div>
                </div><!--/end Filters Container-->

                <div id="grid-container" class="cbp-l-grid-gallery">
                    <div class="cbp-item silikat otdel">
                        <a href="assets/ajax/project1.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0006.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Газосиликат (мкр.Юрьевец)</div>
                                        <div class="cbp-l-caption-desc">Строительство и отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel">
                        <a href="assets/ajax/project2.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0013.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Каркасный дом (п.Ючмер, Владимирская обл.)</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel">
                        <a href="assets/ajax/project3.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0015.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия каркасных домов "Гросс"</div>
                                        <div class="cbp-l-caption-desc">Строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel works">
                        <a href="assets/ajax/project4.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0029.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия каркасных домов "ЭКО"</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item canada karkas works">
                        <a href="assets/ajax/project5.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0037.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия домов "Крутово"</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item canada karkas  works">
                        <a href="assets/ajax/project6.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0041.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Малые архитектурные формы</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="cbp-item karkas otdel">
                        <a href="assets/ajax/project7.html" class="cbp-caption cbp-singlePageInline"
                           data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/p/p0051.JPG" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Серия каркасных домов "БОЛДИНО"</div>
                                        <div class="cbp-l-caption-desc">Проектирование, строительство, отделка</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="karkas cbp-item otdel">
                        <a href="assets/ajax/project10.html" class="cbp-caption cbp-singlePageInline" data-title="">
                            <div class="cbp-caption-defaultWrap">
                                <img src="assets/img/fd2015/portfolio/of2.jpg" alt="формула дома, каркасные дома, канадские дома, строительные работы" width="100%">
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignLeft">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-title">Классический американский дом</div>
                                        <div class="cbp-l-caption-desc">Любые пожелания клиента </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                                
                </div>

                <div class="cbp-l-loadMore-button">
                    <a href="assets/ajax/loadMore.html" class="cbp-l-loadMore-button-link">Загрузить больше</a>
                </div>
            </div>
        </div>

        

                      
    </section>
    <!--  </section>-->
    <!-- Contact Section -->
    <section id="contact" class="contacts-section">
        <div class="container content-lg">
            <div class="title-v1">
                <h2>Контакты</h2>
                <p>Мы всегда можем встретиться в одном из наших офисов <br> или позвоните и наш сотрудник встретится в любом удобном Вам месте.
                <i class="fa fa-phone"></i>+7(910)177-2777, +7(4922) 60-30-06. 
                    

                </p>
                
            </div>
<!-- <div id="alert" class="alert alert-success fade in margin-bottom-40 hidd">
                     <h4>Доставлено!</h4>
                     Мы свяжемся с Вами в ближайшее время.
                 </div>  --> 
            <div class="row contacts-in">
                <div class="col-md-6 md-margin-bottom-40">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-home"></i> г. Владимир, Дворянская 27а </li>
                        <li><i class="fa fa-phone"></i> <tel>+7(4922) 60-30-06</tel></li>

                        <li><i class="fa fa-home"></i> г. Петушки, ТЦ Пятерочка </li>
                        <li><i class="fa fa-phone"></i> <tel>+7(49243) 2-71-10</tel></li>
                        <!-- <li><i class="fa fa-home"></i> г. Покров, ул.Ленина, 92 </li>
                        <li><i class="fa fa-phone"></i> <tel>+7(49243)  6-75-92</tel></li> -->
                        <li><i class="fa fa-envelope"></i> <a href="mailto:house@formula-doma.ru">house@formula-doma.ru</a></li>
                        <li><i class="fa fa-globe"></i> <a href="http://formula-doma.ru">www.formula-doma.ru</a></li>
                    </ul>
                </div>

                <div class="col-md-6">
                <p>Вы так же можете заказать звонок:</p>
                   
                
                    

                    <form name='fdForm' id='fdForm'  action="" method="">
                        <label>Имя</label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-7 col-md-offset-0">
                                <input id="name" name="name" type="text" class="form-control">
                            </div>                
                        </div>
                        <label>Телефон </label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-7 col-md-offset-0">
                                <input id="phone" name="phone" type="text" class="form-control">
                            </div>                
                        </div>
                        <label>Email </label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-7 col-md-offset-0">
                                <input id="email" name="email" type="text" class="form-control">
                            </div>                
                        </div>
                        
                        <label>Сообщение</label>
                        <div class="row margin-bottom-10">
                            <div class="col-md-11 col-md-offset-0">
                                <textarea id="txt" name="txt" rows="4" class="form-control"></textarea>
                            </div>                
                        </div>
                        
                        <p><button type="submit" name="sndbtn" class="btn-u btn-brd btn-brd-hover btn-u-dark">Отправить</button></p>
                    </form> 



                </div>
            </div> 
            
        </div>
      </section>      

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-22905167-4', 'auto');
  ga('send', 'pageview');

</script>



       <div id="mymap" class="rowmap">
            <script type="text/javascript" async  charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=ZSJtiGrWJ8ltnq8gTnIXk1iph1wYJ6T4&width=100%&height=350"></script>
       </div>

        <div class="copyright-section">
         
        

            <p>2015 &copy;  <a target="_blank" href="">ООО "Промедиа 33" - разработка и продвижение сайтов +7 (4922) 604-500</a></p>
            <a href="http://www.stroyserver.ru"><img src="http://www.stroyserver.ru/banner3.gif" width=88 height=31 border=0 alt="Строительная доска объявлений"></a><a target="_blank" href="http://www.electric-house.ru/" title="электропроводка, электрика, электромонтажные работы, электромонтаж в москве"><img src="http://www.electric-house.ru/88x31.gif" width="88" height="31" border="0" alt="электромонтажные работы, электромонтаж в москве"></a>
            <p><a href="http://www.stroi-baza.ru/job/index.php">Строительные вакансии на строительном портале </a></p>
            <!-- <ul class="social-icons">
                <li><a href="#" data-original-title="Facebook" class="social_facebook rounded-x"></a></li>
                <li><a href="#" data-original-title="Twitter" class="social_twitter rounded-x"></a></li>
                <li><a href="#" data-original-title="Goole Plus" class="social_googleplus rounded-x"></a></li>
                <li><a href="#" data-original-title="Pinterest" class="social_pintrest rounded-x"></a></li>
                <li><a href="#" data-original-title="Linkedin" class="social_linkedin rounded-x"></a></li>
            </ul> -->
            <span class="page-scroll"><a href="#intro"><i class="fa fa-angle-double-up back-to-top"></i></a></span>
        </div>


      <!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.ru/stat/?id=31076991&amp;from=informer"
target="_blank" rel="nofollow"><img src="https://bs.yandex.ru/informer/31076991/1_0_20EC20FF_00CC00FF_1_uniques"
style="width:80px; height:15px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (уникальные посетители)" onclick="try{Ya.Metrika.informer({i:this,id:31076991,lang:'ru'});return false}catch(e){}" /></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter31076991 = new Ya.Metrika({
                    id:31076991,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true,
                    trackHash:true,
                    ut:"noindex"
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/31076991?ut=noindex" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
    <!-- End Contact Section -->
    <script type="application/ld+json">
{ "@context" : "http://schema.org",
  "@type" : "Organization",
  "url" : "http://www.formula-doma.ru",
  "contactPoint" : [
    { "@type" : "ContactPoint",
      "telephone" : "+7 (4922) 60-30-06",
      "contactType" : "customer support"
    } ],
    "logo" : "http://www.formula-doma.ru/st.png" }
</script>
        
        


<!--[if lte IE 7]><style type="text/css">.jivo-btn, .jivo-btn-icon  {   display: inline;}</style><![endif]--><!-- JS Global Compulsory -->
    <!-- CSS Global Compulsory -->


    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="assets/css/line-icons.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">    
    <link rel="stylesheet" href="assets/css/pace-flash.css">
   <!--  <link rel="stylesheet" href="assets/plugins/YTPlayer/css/YTPlayer.css"> -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">    
    <link rel="stylesheet" href="assets/css/shortcode_timeline1.css">    
    <link rel="stylesheet" href="assets/css/shortcode_timeline2.css">    
    <link rel="stylesheet" href="assets/css/settings.css" type="text/css" media="screen">

    <!-- load css for cubeportfolio -->
    <link rel="stylesheet" href="assets/css/cubeportfolio.css" type="text/css" >
    <link rel="stylesheet" href="assets/css/custom-cubeportfolio.css"> 

    <!-- load main css for this page -->
    <link rel="stylesheet" href="assets/css/main.css" type="text/css" >
     <!-- CSS Theme -->    
    <link rel="stylesheet" href="assets/css/one.dark.css">

    <!-- CSS Customization -->
    <link rel="stylesheet" href="assets/css/custom.css">
   <!-- JS Global Compulsory -->
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-migrate.min.js"></script>    
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <!-- JS Implementing Plugins -->
    <script type="text/javascript" src="assets/js/smoothScroll.js"></script>    
    <script type="text/javascript" src="assets/js/jquery.easing.min.js"></script>
    <script type="text/javascript" src="assets/js/pace.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.parallax.js"></script>
    <script type="text/javascript" src="assets/js/waypoints.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.counterup.min.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.js"></script>
    <script type="text/javascript" src="assets/js/jquery.form.min.js"></script>    
    <script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.cubeportfolio.min.js"></script>
    <!-- JS Page Level-->
    <script type="text/javascript" src="assets/js/one.app.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>
    <script type="text/javascript" src="assets/js/contact.js"></script>
    <script type="text/javascript" src="assets/js/pace-loader.js"></script>
    <script type="text/javascript" src="assets/js/owl-carousel.js"></script>
    <script type="text/javascript" src="assets/js/revolution-slider.js"></script>
    <script type="text/javascript" src="assets/js/cube-portfolio-lightbox.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function() {
            App.init();
            App.initCounter();
            App.initParallaxBg();
            LoginForm.initLoginForm();
            ContactForm.initContactForm();
            OwlCarousel.initOwlCarousel();
            RevolutionSlider.initRSfullScreen();

            $('#fdForm').submit(function(e){ 
                    e.preventDefault();
                    $.ajax({
                      url: "sendForm.php",
                      type: "POST",
                      data: $('#fdForm').serialize(),
                      success: function(response) {
                        //обработка успешной отправки
                        alert("Отправлено"+this.data);
                        $('#fdForm').trigger( 'reset' );


                      },
                      error: function(response) {
                        //обработка ошибок при отправке
                        alert("Не отправлено")
                      }
                    });
                });
        });
    </script>
     <!--[if lt IE 9]>
        <script src="assets/plugins/respond.js"></script>
        <script src="assets/plugins/html5shiv.js"></script>
    <![endif]-->    <!-- BEGIN JIVOSITE CODE {literal}
<script type='text/javascript'>
(function(){ var widget_id = 'PmQI7Xdv4r';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/geo-widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
{/literal} END JIVOSITE CODE -->


<!-- START ME-TALK -->
<script type='text/javascript'>
	(function() {
		var s = document.createElement('script');
		s.type ='text/javascript';
		s.id = 'supportScript';
		s.charset = 'utf-8';
		s.async = true;
		s.src = '//me-talk.ru/support/support.js?h=a8b6f6602fa6977f8309912546a1cdcf';
		var sc = document.getElementsByTagName('script')[0];
		
		var callback = function(){
			/*
				Здесь вы можете вызывать API. Например, чтобы изменить отступ по высоте:
				supportAPI.setSupportTop(200);
			*/
		};
		
		s.onreadystatechange = s.onload = function(){
			var state = s.readyState;
			if (!callback.done && (!state || /loaded|complete/.test(state))) {
				callback.done = true;
				callback();
			}
		};
		
		if (sc) sc.parentNode.insertBefore(s, sc);
		else document.documentElement.firstChild.appendChild(s);
	})();
</script>
<!-- END ME-TALK -->

<script async="async" src="https://w.uptolike.com/widgets/v1/zp.js?pid=1396066" type="text/javascript"></script>
<!-- 33Live.Ru - Рейтинг сайтов Владимирской области --><script type="text/javascript" src="http://33live.ru/rating/counter/3399"></script><noscript><a href="http://33live.ru/?fromsite=3399" target="_blank"><img src="http://33live.ru/i/button.png" border="0" alt="Рейтинг Владимирских Сайтов" width="90" height="31"></a></noscript><!-- 33Live.Ru - Рейтинг сайтов Владимирской области -->

					<!-- Топ строительных сайтов , HTML code for http://formula-doma.ru -->
		       			<script type="text/javascript">
				          	var refer='refer=' + escape(document.referrer) + '&page=' + escape(window.location.href) + '&razresh=' + screen.width + 'x' + screen.height + '&cvet=' + screen.colorDepth + '&rand=' + Math.random(); 
							document.write('<a href="http://top.zelenopol.net/?fromsite=867"> <img src="http://top.zelenopol.net/img.php?id=867&' + refer + '"  alt="Топ строительных сайтов" width="31" height="31"> <\/a>');
			  			</script>
          				<noscript><div><a href="http://top.zelenopol.net/?fromsite=867" onclick="this.target='_blank'"><img src="http://top.zelenopol.net/img.php?id=867" alt="Топ строительных сайтов" width="31" height="31"></a></div></noscript>
					<!-- /Топ строительных сайтов , HTML code for http://formula-doma.ru -->
			    
</body>

</html>