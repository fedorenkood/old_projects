Модуль WayForPay для Wordpress WooCommerce 
=======

Установка
----
>1. Содержимое архива поместить в папку плагинов  Wordpress ( по-умолчанию - {корень сайта}/wp-content/plugins/)

>2. Зайти в админ раздел сайта  (/wp-admin/) и активировать плагин "WooCommerce - WayForPay"

>3. Перейти в раздел "WooCommerce" -> "Settings" -> "Checkout" 

>4. Внизу страницы в пункте "Payment Gateways", нажать кнопку "Settings" напротив "WayForPay Payments"

>5. Ввести данные вашего мерчанта.


![Settings](https://github.com/wayforpay/Word-Press-Woocommerce/blob/master/settings.png)
