<h2>Overview</h2>

<p>
  This is a walkthrough of each configuration option, designed to help you understand how the plugin works and how the
  different settings interact with each other.  The configuration options are grouped by their basic function.
</p>

<a href="http://www.webtipblog.com/scroll-back-top-wordpress-plugin-button-designs/" target="_blank">Check out some custom button design
  inspiration</a><br>
<a href="http://wordpress.org/plugins/scroll-back-to-top/" target="_blank">Check out the Wordpress Scroll Back to Top plugin page</a>


