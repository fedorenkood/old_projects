Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

https://make.wordpress.org/polyglots/handbook/
http://codex.wordpress.org/Function_Reference/load_theme_textdomain