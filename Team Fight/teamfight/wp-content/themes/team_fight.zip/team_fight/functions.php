<?php
include 'libs/chat/class.db.php';
require ('libs/steamauth/steamauth.php');  
unset($_SESSION['steam_uptodate']);
include 'libs/chat/dialog.php';

add_theme_support( 'title-tag' );

function OnOffLine($state)
{
    
	if ($state==1 or $state==5 or $state==6) {
		echo '<i class="fa fa-circle on" aria-hidden="true"></i>';
	} else {
		echo '<i class="fa fa-circle off" aria-hidden="true"></i>';
	}
}