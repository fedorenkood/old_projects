<div class="hidden">
	<div class="modal_team_find box_elem_midd"  id="premium">
		<div class="modal_content">
			<button class="mfp-close" id="button-close" type="button" title="Закрыть (Esc)">×</button>
			<?php 
			if(isset($_SESSION['steamid'])) {
			?>
			<div class="col-md-12 left">
				<div>
					<img class="prof_pic" src="<?=$steamprofile['avatarfull']?>" alt="Alt" />
					<p class="nickname"><?=$steamprofile['personaname']?></p>
				</div>
			</div>
			
			<div class="col-md-12 right">
				<div class="massage">
					<p id="error"></p>
					<p id="complete"></p>
				</div>
			

				<div class="find_box">
					<button class="find_btn btn">Buy Premium</button>
				</div>
			</div>
			<?php
				} else{
					echo '
					<div class="col-md-12 right">
						<div class="massage">
							<p id="error" style="display: block;">Error! Mate has left chat. You may start new search now.</p>
						</div>
					</div>';
				}
			?>
		</div>
	</div>
</div>