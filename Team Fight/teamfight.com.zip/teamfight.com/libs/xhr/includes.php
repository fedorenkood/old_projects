<?php
// includes
require ('../steamauth/steamauth.php');  
require ('../steamauth/userInfo.php');  
include '../chat/class.db.php';
include '../chat/dialog.php';
$db = new db('mysql.hostinger.com.ua','u356623825_fedor','ubnfhf20','u356623825_fedor');


$steamid = $steamprofile['steamid'];  // 76561198105737570
$userid = $db->getRowById('user', $steamid, 'steamid', 'id');
