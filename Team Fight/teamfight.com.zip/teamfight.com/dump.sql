-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Сен 19 2017 г., 01:07
-- Версия сервера: 10.1.22-MariaDB
-- Версия PHP: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `teamfight`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tf_dialog`
--

CREATE TABLE `tf_dialog` (
  `id` int(11) NOT NULL,
  `public` int(11) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- Структура таблицы `tf_message`
--

CREATE TABLE `tf_message` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `public` int(11) NOT NULL,
  `senderid` int(11) NOT NULL,
  `dialogid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- Структура таблицы `tf_message_to_user`
--

CREATE TABLE `tf_message_to_user` (
  `id` int(11) NOT NULL,
  `messageid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Структура таблицы `tf_user`
--

CREATE TABLE `tf_user` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `steamid` bigint(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(3) NOT NULL,
  `image_full` varchar(500) NOT NULL,
  `cs_go` text NOT NULL,
  `dota` int(11) NOT NULL,
  `lang` varchar(20) NOT NULL,
  `team_num` int(11) NOT NULL,
  `cs_go_st` enum('yes','no','in_chat') NOT NULL DEFAULT 'no',
  `dota_st` enum('yes','no','in_chat') NOT NULL DEFAULT 'no',
  `prem` tinyint(1) NOT NULL,
  `email` varchar(50) NOT NULL,
  `perm` varchar(50) NOT NULL DEFAULT '0|1|1|0|1|1',
  `public` int(11) NOT NULL,
  `lastvisit` int(11) NOT NULL,
  `active` enum('yes','no') NOT NULL DEFAULT 'yes',
  `last_active` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `access` int(11) NOT NULL,
  `salt` varchar(100) NOT NULL,
  `method_notification` smallint(6) NOT NULL DEFAULT '0',
  `login` varchar(50) NOT NULL,
  `image` varbinary(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Структура таблицы `tf_user_to_dialog`
--

CREATE TABLE `tf_user_to_dialog` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dialogid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `tf_dialog`
--
ALTER TABLE `tf_dialog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tf_message`
--
ALTER TABLE `tf_message`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tf_message_to_user`
--
ALTER TABLE `tf_message_to_user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tf_user`
--
ALTER TABLE `tf_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login` (`login`,`image`);

--
-- Индексы таблицы `tf_user_to_dialog`
--
ALTER TABLE `tf_user_to_dialog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `tf_dialog`
--
ALTER TABLE `tf_dialog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT для таблицы `tf_message`
--
ALTER TABLE `tf_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1359;
--
-- AUTO_INCREMENT для таблицы `tf_message_to_user`
--
ALTER TABLE `tf_message_to_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6147;
--
-- AUTO_INCREMENT для таблицы `tf_user`
--
ALTER TABLE `tf_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=372;
--
-- AUTO_INCREMENT для таблицы `tf_user_to_dialog`
--
ALTER TABLE `tf_user_to_dialog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2667;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
